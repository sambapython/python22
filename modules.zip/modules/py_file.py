'''
import f1
print f1.fun()
'''
'''
import mod12
print mod12.file1.fun()
'''
from mod12 import file1

print file1.fun()
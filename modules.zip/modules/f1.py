
def fun():
	return "fun in f1"

def main():
	print fun()
	print "program ended"
	print "program started"


if __name__ == "__main__":
	main()
print "init"
#import file1